import numpy as np
from matplotlib import pyplot as plt
import pandas as pd
import japanize_matplotlib
import sys
ops = ['insert', 'search', 'delete']
logsizes = ['41943328']

colorlst = ['#ffeda0', '#feb24c', '#f03b20']
fontsize = 18
labels = ['HTM-block', 'Checkpoint-block', 'Abort']

for logsize in logsizes:
    for op in ops:
        pmem_file = pd.read_csv(sys.argv[1] + '/wait_' + op + '_plain.logsize.' + logsize + '.csv', index_col=0)
        vmem_file = pd.read_csv(sys.argv[2] + '/wait_' + op + '_plain.logsize.' + logsize + '.csv', index_col=0)
        pmem_file['HTM-block'] *= pmem_file.index
        pmem_file['Checkpoint-block'] *= pmem_file.index
        pmem_file['Abort'] *= pmem_file.index
        vmem_file['HTM-block'] *= vmem_file.index
        vmem_file['Checkpoint-block'] *= vmem_file.index
        vmem_file['Abort'] *= vmem_file.index

        # print(pmem_file)
        # print(vmem_file)
        # print(pmem_file.index)

        xtick = np.array(range(len(pmem_file.index)))
        barwidth = 0.3

        htm_bottom_p = np.zeros(len(pmem_file.index), dtype=int)
        cpt_bottom_p = htm_bottom_p + pmem_file['HTM-block']
        abt_bottom_p = cpt_bottom_p + pmem_file['Checkpoint-block']
        top_p = abt_bottom_p + pmem_file['Abort']
        print(op)
        print(max(top_p))

        htm_bottom_v = np.zeros(len(vmem_file.index), dtype=int)
        cpt_bottom_v = htm_bottom_v + vmem_file['HTM-block']
        abt_bottom_v = cpt_bottom_v + vmem_file['Checkpoint-block']

        fig = plt.figure(figsize=(7, 6))
        plt.xticks(xtick, pmem_file.index)
        plt.bar(xtick-barwidth/2, pmem_file['HTM-block']       , bottom=htm_bottom_p, width=barwidth, edgecolor = 'k', color = colorlst[0], label = labels[0])
        plt.bar(xtick-barwidth/2, pmem_file['Checkpoint-block'], bottom=cpt_bottom_p, width=barwidth, edgecolor = 'k', color = colorlst[1], label = labels[1])
        plt.bar(xtick-barwidth/2, pmem_file['Abort']           , bottom=abt_bottom_p, width=barwidth, edgecolor = 'k', color = colorlst[2], label = labels[2])

        plt.bar(xtick+barwidth/2, vmem_file['HTM-block']       , bottom=htm_bottom_v, width=barwidth, edgecolor = 'k', color = colorlst[0])
        plt.bar(xtick+barwidth/2, vmem_file['Checkpoint-block'], bottom=cpt_bottom_v, width=barwidth, edgecolor = 'k', color = colorlst[1])
        plt.bar(xtick+barwidth/2, vmem_file['Abort']           , bottom=abt_bottom_v, width=barwidth, edgecolor = 'k', color = colorlst[2])

        plt.xlabel('スレッド数', fontsize=fontsize)
        plt.ylabel('総消費時間 (秒)', fontsize=fontsize)
        plt.tick_params(labelsize=fontsize)
        plt.legend(bbox_to_anchor=(0.50, -0.20), loc='center', borderaxespad=0, ncol=3, fontsize=fontsize-4)
        plt.text(1.75, max(top_p)-1, '左：不揮発性メモリ，右：DRAM', fontsize=fontsize-4)
        plt.tight_layout()
        plt.savefig('total_wait_' + op + '_plain_logsize_' + logsize + '.pdf')
        plt.close()
